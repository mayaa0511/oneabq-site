<?php

	define('PERCH_SITEPATH', '$sitepath');

	define('PERCH_SCHEDULE_SECRET', '$secret');

	define('PERCH_DB_USERNAME', '$db_username');
	define('PERCH_DB_PASSWORD', '$db_password');
	define('PERCH_DB_SERVER', 	"$db_server");
	define('PERCH_DB_DATABASE', '$db_database');
	define('PERCH_DB_PREFIX', 	'$db_prefix');

