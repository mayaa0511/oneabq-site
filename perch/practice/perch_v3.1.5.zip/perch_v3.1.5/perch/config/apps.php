<?php
	$apps_list = [ 
	];