<?php
	$API  = new PerchAPI(1.0, 'content');
	$HTML = $API->get('HTML');
	$Lang   = $API->get('Lang');