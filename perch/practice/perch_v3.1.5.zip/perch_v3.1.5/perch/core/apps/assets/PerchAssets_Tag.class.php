<?php

class PerchAssets_Tag extends PerchBase
{
    protected $table  = 'resource_tags';
    protected $pk     = 'tagID';
}
