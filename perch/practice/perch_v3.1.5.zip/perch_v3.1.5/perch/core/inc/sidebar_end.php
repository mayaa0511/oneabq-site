<?php
	ob_clean();