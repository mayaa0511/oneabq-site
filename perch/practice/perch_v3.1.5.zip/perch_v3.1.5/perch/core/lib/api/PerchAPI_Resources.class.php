<?php

class PerchAPI_Resources extends PerchResources {}
