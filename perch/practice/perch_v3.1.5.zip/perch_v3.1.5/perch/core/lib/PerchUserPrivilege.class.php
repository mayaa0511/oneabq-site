<?php

class PerchUserPrivilege extends PerchBase
{
    protected $table  = 'user_privileges';
    protected $pk     = 'privID';
}
