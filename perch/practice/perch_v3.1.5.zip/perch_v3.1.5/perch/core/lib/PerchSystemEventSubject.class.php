<?php

class PerchSystemEventSubject extends StdClass
{

	public function to_array()
	{
		return (array)$this;
	}
}