<?php

class PerchShortcode_Provider
{
	public $shortcodes = [];

	public function get_shortcode_replacement($Sortcode, $Tag)
	{
		return '';
	}
}