These templates are used for the emails Perch sends.

You can change them if you wish. However, always take a backup before upgrading Perch, as they could be overwritten.
If you make changes it's your responsibility to manage the changes at upgrade time.

