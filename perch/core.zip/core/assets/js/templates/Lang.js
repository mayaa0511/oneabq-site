module.exports = function(str) {
	return Perch.Lang.get(str);
};