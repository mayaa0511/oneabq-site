<?php

class PerchAPI_Settings extends PerchSettings
{
    
}
